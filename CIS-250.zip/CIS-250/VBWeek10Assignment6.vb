﻿Public Class Form1

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        ComboBox1.ResetText()
        ComboBox2.ResetText()
        CheckedListBox1.ClearSelected()
        Label7.Text = ""
        Button3.Show()
        Checkout = 0
        Topping = ""

        Dim i As Integer

        For i = 0 To 8
            CheckedListBox1.SetItemChecked(i, False)
        Next


    End Sub

    Dim Print As String = ""    'variable to store the output

    Dim Checkout As Double = 0  'variable to store the Total amount to be paid  

    Dim Topping As String = ""  'variable to store the toppings info

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        'forcing the user to pick a pizza

        If ComboBox1.Text = "" Or ComboBox2.Text = "" Then

            Print = "please make a choice"

        Else

            Dim topcount As Integer = 0 'variable to check toppings selected

            Dim i As Integer    'variable to loop throught the checklistBox

            For i = 0 To 8

                'forcing the user to pick a topping (part1)

                If CheckedListBox1.GetItemChecked(i) = False Then

                    topcount += 1

                End If

                'looking for toppings

                Select Case i
                    Case 0

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If


                    Case 1

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If

                    Case 2

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If

                    Case 3

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If

                    Case 4

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If

                    Case 5

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If

                    Case 6

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If

                    Case 7

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If

                    Case 8

                        If CheckedListBox1.GetItemChecked(i) = True Then

                            Topping += vbCrLf & " + 2.00 " & CheckedListBox1.Items(i).ToString()
                            Checkout += 2.0

                        End If

                End Select

            Next

            If topcount = 9 Then
                Print = "Please pick your toppings"
            Else
                Output()
            End If

        End If

        Label7.Text = Print
        Button3.Hide()

    End Sub

    'Sub for displaying info

    Sub Output()

        Print = "Crust: " + ComboBox1.Text.ToString() +
                    vbCrLf + "Size: " + ComboBox2.Text.ToString() +
                    vbCrLf + "Toppings:" + Topping +
                    vbCrLf + "--------------------------------" +
                    vbCrLf + "$" + CheckoutTotal().ToString() + " Total"

    End Sub

    'Function for Total amount

    Function CheckoutTotal() As Double

        Checkout += PizzaCrust() + PizzaSize()

        Return Checkout

    End Function

    'Find Crust

    Function PizzaCrust() As Double

        Dim _Crust As Double = 0
        Dim i As Integer

        For i = 0 To 1

            If ComboBox1.SelectedIndex = 1 Then

                _Crust = 8.0

            Else

                _Crust = 5.0

            End If

        Next

        Return _Crust

    End Function

    'Find Size

    Function PizzaSize() As Double

        Dim _Size As Double

        Dim i As Integer

        For i = 0 To 2

            If ComboBox2.SelectedIndex = 1 Then

                _Size = 3.0

            ElseIf ComboBox2.SelectedIndex = 2 Then

                _Size = 5.0

            End If

        Next


        Return _Size

    End Function
End Class
