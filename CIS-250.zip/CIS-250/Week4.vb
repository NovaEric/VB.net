﻿Module Module1

    Sub Main()

        Dim month As Integer
        Dim breaker As String

        breaker = "n"


        While (breaker = "n")


            Try
                Console.Write("Enter a month number (e.g. 1 = January, etc.), ctrl C to exit: ")
                month = Console.ReadLine()
            Catch ex As Exception
                Console.WriteLine("Enter valid inputs only!")
                month = 0
            End Try

            If month >= 1 And month <= 12 Then

                Select Case month
                    Case 1
                        Console.WriteLine("The month you have entered is JANUARY!")
                        Console.WriteLine("January is also National Book Month and International Creativity Month.")
                    Case 2
                        Console.WriteLine("The month you have entered is FEBRUARY!")
                        Console.WriteLine("February is also Black History Month and includes International Snow Sculpting Week.")
                    Case 3
                        Console.WriteLine("The month you have entered is MARCH!")
                        Console.WriteLine("March is also Women's History Month and includes International Brain Awareness Week.")
                    Case 4
                        Console.WriteLine("The month you have entered is APRIL!")
                        Console.WriteLine("April is the Month of the Military Child and Math Awareness Month.")
                    Case 5
                        Console.WriteLine("The month you have entered is MAY!")
                        Console.WriteLine("Mother's Day and Memorial Day are two of the holidays celebrated in May.")
                    Case 6
                        Console.WriteLine("The month you have entered is JUN!")
                        Console.WriteLine("June is also National Audio Book Month.")
                    Case 7
                        Console.WriteLine("The month you have entered is JULY!")
                        Console.WriteLine("July is National Anti-Boredom month. Also Independence Day and Video Games Day are celebrated in July.")
                    Case 8
                        Console.WriteLine("The month you have entered is AUGUST!")
                        Console.WriteLine("Family Fun Month. It's a time for the whole family to enjoy time together before school starts.")
                    Case 9
                        Console.WriteLine("The month you have entered is SEPTEMBER!")
                        Console.WriteLine("Family Fun Month. It's a time for the whole family to enjoy time together before school starts.")
                    Case 10
                        Console.WriteLine("The month you have entered is OCTOBER!")
                        Console.WriteLine("October is also Sarcastic Month and includes Chemistry Week.")
                    Case 11
                        Console.WriteLine("The month you have entered is NOVEMBER!")
                        Console.WriteLine("In November, you start to move into what is often called the holiday season, with Thanksgiving leading the way.")
                    Case 12
                        Console.WriteLine("The month you have entered is DECEMBER!")
                        Console.WriteLine("Christmas, Hanukkah, and New Year's Eve in December? December is also Write a Friend Month.")
                End Select

            Else
                Console.WriteLine("Sorry, not a valid month!")
                Console.WriteLine("Want out? Yes = y, No = n: ")
                breaker = Console.ReadLine()

                If (breaker = "y") Then
                    Exit Sub
                Else
                    Console.WriteLine("You have entered 'NO' or an invalid answer")
                End If

            End If

        End While

    End Sub

End Module
