﻿Module Module1

    Sub Main()
        Display()
    End Sub
    'display
    Sub Display()
        Dim taxRate, unitPrice, taxes, subtotal, total As Double
        Dim quantity As Integer
        Const QUIT As Double = 0

        Do
            Try
                Console.WriteLine("")
                memo()
                Console.WriteLine("Enter tax rate porcentage: ")
                taxRate = Console.ReadLine()
                Console.WriteLine("Enter Unit price: ")
                unitPrice = Console.ReadLine()
                Console.WriteLine("Enter quantity: ")
                quantity = Console.ReadLine()

                subtotal = computeSubtotal(unitPrice, quantity)
                taxes = computeTax(taxRate, subtotal)
                total = computeTotal(taxes, subtotal)

                Console.WriteLine("Subtotal: " + subtotal.ToString)
                Console.WriteLine("Tax: " + taxes.ToString)
                Console.WriteLine("Total: " + total.ToString)

            Catch ex As Exception

                Console.WriteLine("Wrong entry. Only number please! ")

            End Try

        Loop While (unitPrice Or taxRate Or quantity) <> QUIT
        ' Repeat until user says quit
    End Sub
    'Memo
    Sub memo()
        Console.WriteLine("****************************Enter 0 to all or ctrl C to exit")
    End Sub

    'Subtotal
    Private Function computeSubtotal(unit As Double, qty As Integer) As Double
        Return unit * qty
    End Function

    'Taxes
    Private Function computeTax(tax As Double, subtotal As Double) As Double
        Return (tax / 100) * subtotal
    End Function

    'Total
    Private Function computeTotal(tax As Double, subtotal As Double) As Double
        Return tax + subtotal
    End Function

End Module
