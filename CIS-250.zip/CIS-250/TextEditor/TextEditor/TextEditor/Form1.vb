﻿Public Class Form1

    Const FILENAME As String = "save.txt"

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        My.Computer.FileSystem.WriteAllText(FILENAME, txtEditor.Text, False)
    End Sub


    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        txtEditor.Text = My.Computer.FileSystem.ReadAllText(FILENAME)
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub
End Class
