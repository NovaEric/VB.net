﻿' Equality and relational operators
' =  equal to
' <> not equal to
' >  greater than
' >= greater than or equal to
' <  less than
' <= less than or equal to

' AND
' True And True = True
' True And False = False
' False And True = False
' False And False = False

' OR
' True Or True = True
' True Or False = True
' False Or True = True
' False Or False = False

' XOR
' True Xor True = False
' True Xor False = True
' False Xor True = True
' False Xor False = False

' NOT
' Not True = False
' Not False = True

Module Week4Demo

    Sub Main()
        Dim age As Integer

        Console.Write("Enter your age:  ")
        age = Console.ReadLine()

        If age >= 20 And age <= 29 Then
            Console.WriteLine("Welcome to the club!")
        ElseIf age < 20 Then
            Console.WriteLine("Sorry.  Come back when you're older.")
        Else
            Console.WriteLine("Sorry, it's too late for you.")
        End If

        Dim day As Char
        Console.Write("What day is it? (M, T, W, R, F) ")
        day = Console.ReadLine()

        Select Case day
            Case "M"
                Console.WriteLine("I hate Mondays.")
            Case "T"
                Console.WriteLine("Tuesday!  I hope there are tacos.")
            Case "W"
                Console.WriteLine("Wednesday is hump day. The weekend approaches.")
            Case "R"
                Console.WriteLine("So Happy It's Thursday.")
            Case "F"
                Console.WriteLine("TGIF!")
            Case Else
                Console.WriteLine("I don't recognize that day")
        End Select

        Console.ReadLine()
    End Sub

End Module
