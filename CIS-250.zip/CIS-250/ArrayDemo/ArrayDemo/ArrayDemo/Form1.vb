﻿Public Class Form1

    Const MAX_ITEMS As Integer = 10 ' Max number of items
    Dim shoppingList(MAX_ITEMS - 1) As String ' Array of items
    Dim prices(MAX_ITEMS - 1) As Double
    Dim count As Integer = 0 ' Number of items added to list

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        If count >= MAX_ITEMS Then
            MessageBox.Show("List is full")
            Return
        End If

        Dim item As String
        item = txtItem.Text
        shoppingList(count) = item
        prices(count) = txtPrice.Text
        txtItem.Text = ""
        txtPrice.Text = ""
        count = count + 1

        Dim output As String = ""
        ' For Each item In shoppingList
        For i As Integer = 0 To count - 1
            output = output & (i + 1) & ". " & shoppingList(i)
            output = output & " (" & FormatCurrency(prices(i)) & ")"
            output = output & vbCrLf
        Next
        txtShoppingList.Text = output

    End Sub
End Class
