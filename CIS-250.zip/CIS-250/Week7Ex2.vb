﻿Module Week7Ex2

    Function computeSubtotal(unitPrice As Double, quantity As Integer) As Double
        Return unitPrice * quantity
    End Function

    Function computeTax(subtotal As Double, taxRate As Double) As Double
        Return subtotal * taxRate
    End Function

    Function computeTotal(subtotal As Double, taxAmt As Double) As Double
        Return subtotal + taxAmt
    End Function

    Sub Main()
        ' Input variables
        Dim taxRate As Double
        Dim unitPrice As Double
        Dim quantity As Integer
        ' Output variables
        Dim subtotal As Double
        Dim taxAmt As Double
        Dim total As Double

        ' Input phase
        Console.Write("Tax rate (0.07 = 7%): ")
        taxRate = Console.ReadLine
        Console.Write("Price per item: $")
        unitPrice = Console.ReadLine
        Console.Write("Number of items purchased: ")
        quantity = Console.ReadLine

        ' Processing phase
        subtotal = computeSubtotal(unitPrice, quantity)
        taxAmt = computeTax(subtotal, taxRate)
        total = computeTotal(subtotal, taxAmt)

        ' Output phase
        Console.WriteLine("Subtotal:  {0:C}", subtotal)
        Console.WriteLine("Sales Tax:  {0:C}", taxAmt)
        Console.WriteLine("Total:  {0:C}", total)

        Console.ReadLine()
    End Sub

End Module
