﻿Module Module1

    Sub Main()

        Dim loopbreaker As Boolean = True
        Dim total, subtotal, Tax As Double

        Console.WriteLine("Welcome!")

        While loopbreaker = True


            Console.WriteLine("Subtotal: " + subtotal.ToString())
            Select Case menu()
                Case 1
                    subtotal += BagOfChips()

                Case 2
                    subtotal += soda()

                Case 3
                    subtotal += candybar()

                Case 4
                    subtotal = 0
                    Tax = 0
                    total = 0
                    Console.Clear()
                    Main()

                Case 5

                    Tax = subtotal * Taxes()
                    total = subtotal + Tax
                    Console.WriteLine("Subtotal: " + subtotal.ToString())
                    Console.WriteLine("Tax: " + Tax.ToString())
                    Console.WriteLine("Total: " + total.ToString())
                    Console.ReadKey()
                    subtotal = 0
                    Tax = 0
                    total = 0
                    Console.Clear()
                    Main()

                Case Else
                    loopbreaker = False

            End Select
            Console.Clear()
        End While

    End Sub
    'Bag of Ships
    Private Function BagOfChips() As Double

        Dim ships As Double

        ships = 1.5

        Return ships
    End Function
    'Soda
    Private Function soda() As Double

        Dim pop As Double

        pop = 1.0

        Return pop
    End Function
    'Candy bar
    Private Function candybar() As Double

        Dim bar As Double

        bar = 2.5

        Return bar
    End Function
    'Taxes
    Private Function Taxes() As Double

        Dim Tax As Double

        Tax = 0.1

        Return Tax
    End Function
    'menu
    Private Function menu() As Double


        Dim sel As Double
        Try
            Console.WriteLine("")
            Console.WriteLine("**********************************")
            Console.WriteLine("1. Bag Of Chips ")
            Console.WriteLine("2. Can Of Soda ")
            Console.WriteLine("3. Candy Bar ")
            Console.WriteLine("4. Start Over ")
            Console.WriteLine("5. Check Out ")
            Console.WriteLine("Enter choice or any key to exit")
            Console.WriteLine("**********************************")
            sel = Console.ReadLine()

        Catch ex As Exception
            Console.WriteLine("Invalid Entry")
        End Try

        Return sel

    End Function

End Module
