﻿Module Module1


    Sub Main()

        Dim points As Double = 0
        Dim student As String = ""
        Dim loopbreaker As Boolean = True

        While loopbreaker = True

            Try
                Console.WriteLine("")
                Console.WriteLine("Enter Student Name: ")
                student = Console.ReadLine()
                Console.WriteLine("Enter Student Acumulated Points: ")
                points = Console.ReadLine()

                If points < 0 Or points > 1000 Then

                    Console.WriteLine("")
                    Console.WriteLine("Out of range values try again!")
                    Console.WriteLine("")
                    Console.WriteLine("Want Out? y/n ")
                    Console.WriteLine("")

                    If Console.ReadLine() = "y" Then
                        loopbreaker = False
                    End If

                Else

                    Console.WriteLine("")
                    Console.WriteLine("Student's Name: " + student)
                    Console.WriteLine("Student's Total Points: " + Convert.ToString(points))
                    Console.WriteLine("Student's Average Final Grade: " + Convert.ToString(CalcPoints(points)) + "%")
                    Console.WriteLine("Student's Final Letter grade: " + Grades((CalcPoints(points))))

                    Console.WriteLine("")
                    Console.WriteLine("Want Out? y/n ")
                    Console.WriteLine("")

                    If Console.ReadLine() = "y" Then
                        loopbreaker = False
                    End If

                End If

            Catch ex As Exception

                Console.WriteLine("")
                Console.WriteLine("Invalid entry!")
                Console.WriteLine("")
                Console.WriteLine("Want Out? y/n ")
                Console.WriteLine("")

                If Console.ReadLine() = "y" Then
                    loopbreaker = False
                End If

            End Try

        End While


    End Sub

    'calculate Points in porcentage
    Private Function CalcPoints(p) As Double

        Dim MaxPoints, CurrentPoints As Double

        MaxPoints = 1000
        CurrentPoints = (p / MaxPoints) * 100

        Return CurrentPoints

    End Function


    'calculate final grade

    Private Function Grades(g) As String

        Dim LetterGrade As String

        Select Case g
            Case 90 To 100
                LetterGrade = "A"
            Case 80 To 89
                LetterGrade = "B"
            Case 70 To 79
                LetterGrade = "C"
            Case 60 To 69
                LetterGrade = "D"
            Case 0 To 59
                LetterGrade = "F"
            Case Else
                LetterGrade = "Not Graded"
        End Select

        Return LetterGrade

    End Function

End Module
