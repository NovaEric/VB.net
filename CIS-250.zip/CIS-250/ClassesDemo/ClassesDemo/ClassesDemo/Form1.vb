﻿Public Class Form1
    Const NUM_CONTACTS As Integer = 20
    Private contacts(NUM_CONTACTS) As Contact
    Private count As Integer = 0

    Private Sub displayContacts()
        Dim str As String
        str = "First Name" & vbTab
        str &= "Last Name" & vbTab
        str &= "Email Address" & vbTab
        str &= "Phone Number" & vbCrLf

        'For Each c As Contact In contacts
        For i As Integer = 0 To count
            Dim c As Contact = contacts(i)
            str &= c.FirstName & vbTab
            str &= c.LastName & vbTab
            str &= c.EmailAddress & vbTab
            str &= c.PhoneNumber & vbCrLf
        Next

        txtOutput.Text = str
    End Sub

    Private Sub btnAddContact_Click(sender As Object, e As EventArgs) Handles btnAddContact.Click

        If count >= NUM_CONTACTS Then
            MessageBox.Show("Address book is full.")
            Return
        End If

        ' Create Contact object
        Dim data As New Contact

        ' Fill Contact object with user input
        data.FirstName = txtFirstName.Text
        data.LastName = txtLastName.Text
        data.PhoneNumber = txtPhone.Text
        data.EmailAddress = txtEmail.Text

        ' Add Contact to array
        contacts(count) = data

        ' Show the updated list of contacts
        displayContacts()

        ' Add one to the number of contacts entered
        count += 1
    End Sub

    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        txtOutput.Text = "Search key not found."
        Dim key As String = txtFirstName.Text
        For i As Integer = 0 To count - 1
            If contacts(i).FirstName = key Then
                txtOutput.Text = "Name: " & contacts(i).FirstName & " "
                txtOutput.Text &= contacts(i).LastName & vbCrLf
                txtOutput.Text &= "Email: " & contacts(i).EmailAddress & vbCrLf
                txtOutput.Text &= "Phone: " & contacts(i).PhoneNumber & vbCrLf
            End If
        Next

    End Sub

    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        txtOutput.Text = "Search key not found."
        Dim key As String = txtLastName.Text
        For i As Integer = 0 To count - 1
            If contacts(i).LastName = key Then
                txtOutput.Text = "Name: " & contacts(i).FirstName & " "
                txtOutput.Text &= contacts(i).LastName & vbCrLf
                txtOutput.Text &= "Email: " & contacts(i).EmailAddress & vbCrLf
                txtOutput.Text &= "Phone: " & contacts(i).PhoneNumber & vbCrLf
            End If
        Next


    End Sub

    Private Sub btnEmail_Click(sender As Object, e As EventArgs) Handles btnEmail.Click
        txtOutput.Text = "Search key not found."
        Dim key As String = txtEmail.Text
        For i As Integer = 0 To count - 1
            If contacts(i).EmailAddress = key Then
                txtOutput.Text = "Name: " & contacts(i).FirstName & " "
                txtOutput.Text &= contacts(i).LastName & vbCrLf
                txtOutput.Text &= "Email: " & contacts(i).EmailAddress & vbCrLf
                txtOutput.Text &= "Phone: " & contacts(i).PhoneNumber & vbCrLf
            End If
        Next


    End Sub

    Private Sub btnPhone_Click(sender As Object, e As EventArgs) Handles btnPhone.Click
        txtOutput.Text = "Search key not found."
        Dim key As String = txtPhone.Text
        For i As Integer = 0 To count - 1
            If contacts(i).PhoneNumber = key Then
                txtOutput.Text = "Name: " & contacts(i).FirstName & " "
                txtOutput.Text &= contacts(i).LastName & vbCrLf
                txtOutput.Text &= "Email: " & contacts(i).EmailAddress & vbCrLf
                txtOutput.Text &= "Phone: " & contacts(i).PhoneNumber & vbCrLf
            End If
        Next


    End Sub
End Class
