﻿Public Class Form1
    Private vectors As New VectorList


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtX.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim v As New Vector2D
        v.X = txtX.Text
        v.Y = txtY.Text

        txtX.Text = ""
        txtY.Text = ""

        vectors.add(v)

        Dim output As String = ""
        For i As Integer = 0 To vectors.Count - 1
            output = output & vectors.getVector(i).toString() & vbCrLf
        Next

        txtOutput.Text = output

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        vectors.saveFile()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        vectors.loadFile()

        Dim output As String = ""
        For i As Integer = 0 To vectors.Count - 1
            output = output & vectors.getVector(i).toString() & vbCrLf
        Next

        txtOutput.Text = output

    End Sub
End Class
