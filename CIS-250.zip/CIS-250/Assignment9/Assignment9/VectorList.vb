﻿Public Class VectorList
    Const MAX_COUNT As Integer = 100
    Private m_vectors(MAX_COUNT) As Vector2D
    Private m_count As Integer = 0
    Const FILENAME As String = "vectors.csv"


    Public Sub add(v As Vector2D)
        m_vectors(m_count) = v
        m_count += 1
    End Sub

    Public Function getVector(ByVal index As Integer) As Vector2D
        If index >= 0 And index < m_count Then
            Return m_vectors(index)
        End If

        Return Nothing
    End Function

    Public ReadOnly Property Count() As Integer
        Get
            Return m_count
        End Get
    End Property

    Public Sub saveFile()
        For i As Integer = 0 To m_count - 1
            Dim v As Vector2D = m_vectors(i)
            Dim output As String
            output = v.X & "," & v.Y & vbCrLf
            My.Computer.FileSystem.WriteAllText(FILENAME, output, True)
        Next
    End Sub

    Public Sub loadFile()
        Try
            Dim MyReader As New FileIO.TextFieldParser(FILENAME)
            MyReader.TextFieldType = FileIO.FieldType.Delimited
            MyReader.SetDelimiters(",")

            While Not MyReader.EndOfData

                ' Read in the next line of data
                Dim fields() As String = MyReader.ReadFields()

                ' Build a contact object from the new data
                Dim data As New Vector2D
                data.X = fields(0)
                data.Y = fields(1)

                ' Add Contact to array
                add(data)
            End While
        Catch ex As System.IO.FileNotFoundException
            MessageBox.Show("File not found.")
        End Try

    End Sub

End Class
