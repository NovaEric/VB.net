﻿Module MenuDemo2

    Sub showValues(a As Double, b As Double)
        Console.Write(vbCrLf & "a = " & a)
        Console.WriteLine(vbTab & "b = " & b)
    End Sub

    Sub showMenu()
        Console.WriteLine()
        Console.WriteLine("A.  Change value of a")
        Console.WriteLine("B.  Change value of b")
        Console.WriteLine("C.  Add a + b")
        Console.WriteLine("D.  Subtract a - b")
        Console.WriteLine("E.  Multiply a * b")
        Console.WriteLine("F.  Divide a / b")
        Console.WriteLine("G.  Quit")
    End Sub

    Function inputSelection() As Char
        Console.Write("Enter selection: ")
        Return Console.ReadLine()
    End Function

    Function inputNewValue() As Double
        Console.Write("Enter new value: ")
        Return Console.ReadLine()
    End Function

    Function add(a As Double, b As Double) As Double
        Return a + b
    End Function

    Function subtract(a As Double, b As Double) As Double
        Return a - b
    End Function

    Function multiply(a As Double, b As Double) As Double
        Return a * b
    End Function

    Function divide(a As Double, b As Double) As Double
        Dim result As Double = 0.0

        If (b = 0) Then
            Console.WriteLine("ERROR:  Cannot divide by zero.")
        Else
            result = a / b
        End If

        Return result
    End Function

    Sub processSelection(selection As Char, ByRef a As Double, ByRef b As Double)
        Select Case selection
            Case "A", "a"
                a = inputNewValue()
            Case "B", "b"
                b = inputNewValue()
            Case "C", "c"
                Console.WriteLine("{0} + {1} = {2}", a, b, add(a, b))
            Case "D", "d"
                Console.WriteLine("{0} - {1} = {2}", a, b, subtract(a, b))
            Case "E", "e"
                Console.WriteLine("{0} * {1} = {2}", a, b, multiply(a, b))
            Case "F", "f"
                Console.WriteLine("{0} / {1} = {2}", a, b, divide(a, b))
            Case "G", "g"
                Console.WriteLine("Exiting program...")
            Case Else
                Console.WriteLine("ERROR:  Invalid selection.")
        End Select
    End Sub

    Sub Main()
        Dim a As Double
        Dim b As Double
        Dim selection As Char
        Const QUIT As Char = "G"

        Do
            showValues(a, b)
            showMenu()
            selection = inputSelection() ' Get user's selection
            processSelection(selection, a, b) ' Respond to selection
        Loop While UCase(selection) <> QUIT
        ' Repeat until user says quit
    End Sub

End Module
