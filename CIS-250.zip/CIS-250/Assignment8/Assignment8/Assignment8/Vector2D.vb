﻿Public Class Vector2D
    Private m_x As Double
    Private m_y As Double

    Public Property X() As Double
        Get
            Return m_x
        End Get
        Set(value As Double)
            m_x = value
        End Set
    End Property

    Public Property Y() As Double
        Get
            Return m_y
        End Get
        Set(value As Double)
            m_y = value
        End Set
    End Property

    Public Sub add(v As Vector2D)
        m_x += v.X
        m_y += v.Y
    End Sub

    Public Sub subtract(v As Vector2D)
        m_x -= v.X
        m_y -= v.Y
    End Sub

    Public Sub multiply(scalar As Double)
        m_x *= scalar
        m_y *= scalar
    End Sub

    Public Function magnitude() As Double
        Dim xSqr As Double = m_x * m_x
        Dim ySqr As Double = m_y * m_y
        Return Math.Sqrt(xSqr + ySqr)
    End Function

    Public Sub normalize()
        m_x /= magnitude()
        m_y /= magnitude()
    End Sub

    Public Function clone() As Vector2D
        Dim v As New Vector2D()
        v.X = m_x
        v.Y = m_y
        Return v
    End Function

    Public Function distance(v As Vector2D) As Double
        Dim diff As Vector2D = clone()
        diff.subtract(v)
        Return diff.magnitude()
    End Function

    Public Overrides Function toString() As String
        Return "(" & m_x & ", " & m_y & ")"
    End Function
End Class
