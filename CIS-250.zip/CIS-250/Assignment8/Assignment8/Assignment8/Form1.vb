﻿Public Class Form1

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim vA As New Vector2D
        Dim vB As New Vector2D
        vA.X = txtAX.Text
        vA.Y = txtAY.Text
        vB.X = txtBX.Text
        vB.Y = txtBY.Text

        ' magnitude test
        txtMagA.Text = vA.magnitude()
        txtMagB.Text = vB.magnitude()

        ' normalization test
        Dim normA As Vector2D = vA.clone()
        normA.normalize()
        txtAXNorm.Text = normA.X
        txtAYNorm.Text = normA.Y
        txtAMagNorm.Text = normA.magnitude()

        Dim normB As Vector2D = vB.clone()
        normB.normalize()
        txtBXNorm.Text = normB.X
        txtBYNorm.Text = normB.Y
        txtBMagNorm.Text = normB.magnitude()

        Dim addTest As Vector2D = vA.clone()
        addTest.add(vB)
        txtAdd.Text = addTest.toString()

        Dim subtractTest As Vector2D = vA.clone()
        subtractTest.subtract(vB)
        txtSubtract.Text = subtractTest.toString()

        Dim multiplyTest As Vector2D = vA.clone()
        multiplyTest.multiply(2)
        txtMultiply.Text = multiplyTest.toString()

        Dim distanceTest As Vector2D = vA.clone()
        txtDistance.Text = distanceTest.distance(vB)

    End Sub
End Class
