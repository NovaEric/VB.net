﻿Public Class Sprite
    Public position As New Vector2D
    Public velocity As New Vector2D
    Public color As Brush

    Public Sub update()
        position.add(velocity)
    End Sub

    Public Sub draw(ByRef g As Graphics)
        Dim ix As Integer = position.X
        Dim iy As Integer = position.Y
        g.FillEllipse(color, ix, iy, 20, 20)
    End Sub

End Class
