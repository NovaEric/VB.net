﻿Public Class Form1

    Private guy As New Sprite()
    'Private sprites(11) As Sprite
    Private sprites As New ArrayList
    Private projectiles As New ArrayList

    Dim buffer As Bitmap

    Private Sub Form1_Paint(sender As Object, e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = Graphics.FromImage(Buffer)
        g.FillRectangle(Brushes.Black, 0, 0, Me.Width, Me.Height)

        Dim width As Integer = Me.Width / 2
        g.DrawRectangle(Pens.ForestGreen, 10, 20, width, 20)

        g.FillEllipse(Brushes.White, 10, 100, width, 40)

        For Each s As Sprite In sprites
            s.draw(g)
        Next

        For Each bullet As Sprite In projectiles
            bullet.draw(g)
        Next


        guy.draw(g)

        Dim p As New Pen(Color.Black)
        p.Width = 5
        g.DrawLine(p, 100, 10, 300, 250)


        e.Graphics.DrawImage(buffer, 0, 0)

    End Sub

    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        Me.Refresh()

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        guy.update()

        'For Each bullet As Sprite In projectiles
        For i As Integer = 0 To projectiles.Count - 1
            Dim bullet As Sprite = projectiles(i)
            bullet.update()
            If bullet.position.Y < 0 Then
                projectiles.Remove(bullet)
                Exit For
            End If
        Next

        For Each bullet As Sprite In projectiles
            For i As Integer = 0 To sprites.Count - 1
                Dim target As Sprite = sprites(i)
                If bullet.position.distance(target.position) < 20 Then
                    sprites.Remove(target)
                    Exit For
                End If
            Next
        Next

        For Each s As Sprite In sprites
            s.update()
            If s.position.X < 0 Then
                s.position.X = Me.Width
            ElseIf s.position.X > Me.Width Then
                s.position.X = 0
            ElseIf s.position.Y < 0 Then
                s.position.Y = Me.Height
            ElseIf s.position.Y > Me.Height Then
                s.position.Y = 0
            End If
        Next

        Refresh()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Buffer = New Bitmap(Me.Width, Me.Height)
        guy.position.X = Me.Width / 2
        guy.position.Y = Me.Height - 100
        guy.color = Brushes.Yellow

        Dim rand As New Random()
        For i = 0 To 10
            Dim s As New Sprite()
            s.position.X = rand.NextDouble() * Me.Width
            s.position.Y = rand.NextDouble() * Me.Height
            s.velocity.X = -10 + rand.NextDouble() * 20
            s.velocity.Y = -10 + rand.NextDouble() * 20
            s.color = Brushes.CornflowerBlue

            sprites.Add(s)
        Next

        Timer1.Start()
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Right Then
            guy.velocity.X = 5
        ElseIf e.KeyCode = Keys.Left Then
            guy.velocity.X = -5
        ElseIf e.KeyCode = Keys.Space Then
            Dim s As New Sprite
            s.position = guy.position.clone()
            s.velocity.Y = -20
            s.color = Brushes.LightGreen
            projectiles.Add(s)
        End If

    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        If e.KeyCode = Keys.Right Or e.KeyCode = Keys.Left Then
            guy.velocity.X = 0
        End If
    End Sub
End Class
