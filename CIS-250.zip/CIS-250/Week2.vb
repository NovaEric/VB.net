﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim name As String
        Dim result As String

        name = InputBox("Hello! What is your name? ")
        result = "Nice To meet you " + name + " !"
        MessageBox.Show(result)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim amount, tip, totaltip, total As Decimal

        amount = CDbl(InputBox("Enter bill amount"))
        tip = CDbl(InputBox("Enter tip %"))
        totaltip = (tip / 100) * amount
        total = totaltip + amount

        MessageBox.Show("Tip Amount: $" + totaltip.ToString + Environment.NewLine +
                        "Total bill Amount: $" + total.ToString)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim item1, item2, tax, totalitems, total As Decimal

        item1 = CDbl(InputBox("Enter first item"))
        item2 = CDbl(InputBox("Enter second item"))
        totalitems = item1 + item2
        tax = totalitems * 0.07
        total = tax + totalitems

        MessageBox.Show("Tax Amount: $" + tax.ToString + Environment.NewLine +
                        "Total bill Amount: $" + total.ToString)
    End Sub
End Class
