﻿Public Class Form1

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim vA As New Vector2D
        Dim vB As New Vector2D
        Dim vC As New Vector2D
        Dim vD As New Vector2D

        vA.X = txtAX.Text
        vA.Y = txtAY.Text
        vB.X = txtBX.Text
        vB.Y = txtBY.Text
        vC.X = txtCX.Text
        vC.Y = txtCY.Text
        vD.X = txtDX.Text
        vD.Y = txtDY.Text

        ' magnitude test
        txtMagA.Text = vA.magnitude()
        txtMagB.Text = vB.magnitude()
        txtMagC.Text = vC.magnitude()
        txtMagD.Text = vC.magnitude()

        ' normalization test
        Dim normA As Vector2D = vA.clone()
        normA.normalize()
        txtAXNorm.Text = normA.X
        txtAYNorm.Text = normA.Y
        txtAMagNorm.Text = normA.magnitude()

        Dim normB As Vector2D = vB.clone()
        normB.normalize()
        txtBXNorm.Text = normB.X
        txtBYNorm.Text = normB.Y
        txtBMagNorm.Text = normB.magnitude()

        Dim normC As Vector2D = vC.clone()
        normC.normalize()
        txtCXNorm.Text = normC.X
        txtCYNorm.Text = normC.Y
        txtCMagNorm.Text = normC.magnitude()

        Dim normD As Vector2D = vD.clone()
        normD.normalize()
        txtDXNorm.Text = normD.X
        txtDYNorm.Text = normD.Y
        txtDMagNorm.Text = normD.magnitude()

        'A & B
        Dim addTest As Vector2D = vA.clone()
        addTest.add(vB)
        txtAdd.Text = addTest.toString()

        Dim subtractTest As Vector2D = vA.clone()
        subtractTest.subtract(vB)
        txtSubtract.Text = subtractTest.toString()

        Dim multiplyTest As Vector2D = vA.clone()
        multiplyTest.multiply(2)
        txtMultiply.Text = multiplyTest.toString()

        Dim distanceTest As Vector2D = vA.clone()
        txtDistance.Text = distanceTest.distance(vB)

        'C & D
        Dim addTest2 As Vector2D = vC.clone()
        addTest2.add(vD)
        txtaddCD.Text = addTest2.toString()

        Dim subtractTest2 As Vector2D = vC.clone()
        subtractTest2.subtract(vD)
        txtsubCD.Text = subtractTest2.toString()

        Dim multiplyTest2 As Vector2D = vC.clone()
        multiplyTest2.multiply(2)
        txtMultiplyCD.Text = multiplyTest2.toString()

        Dim distanceTest2 As Vector2D = vC.clone()
        txtdisCD.Text = distanceTest2.distance(vD)

    End Sub

    Private Sub GroupBox8_Enter(sender As Object, e As EventArgs) Handles GroupBox8.Enter

    End Sub

    Private Sub GroupBox7_Enter(sender As Object, e As EventArgs) Handles GroupBox7.Enter

    End Sub
End Class
