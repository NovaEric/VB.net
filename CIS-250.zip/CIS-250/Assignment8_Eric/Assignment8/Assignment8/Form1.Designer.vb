﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtMagA = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtAY = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtAX = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtMagB = New System.Windows.Forms.TextBox()
        Me.txtBY = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBX = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtAMagNorm = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtAYNorm = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtAXNorm = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtBMagNorm = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtBYNorm = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtBXNorm = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtAdd = New System.Windows.Forms.TextBox()
        Me.txtSubtract = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtMultiply = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtDistance = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtMagD = New System.Windows.Forms.TextBox()
        Me.txtDY = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtDX = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.txtMagC = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtCY = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtCX = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.txtDMagNorm = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtDYNorm = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtDXNorm = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.txtCMagNorm = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtCYNorm = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtCXNorm = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtdisCD = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtMultiplyCD = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtsubCD = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtaddCD = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 31)
        Me.Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "x:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtMagA)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtAY)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtAX)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(26, 25)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox1.Size = New System.Drawing.Size(294, 177)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Vector A"
        '
        'txtMagA
        '
        Me.txtMagA.Location = New System.Drawing.Point(146, 125)
        Me.txtMagA.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtMagA.Name = "txtMagA"
        Me.txtMagA.Size = New System.Drawing.Size(114, 31)
        Me.txtMagA.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 125)
        Me.Label5.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(118, 25)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "magnitude:"
        '
        'txtAY
        '
        Me.txtAY.Location = New System.Drawing.Point(146, 77)
        Me.txtAY.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtAY.Name = "txtAY"
        Me.txtAY.Size = New System.Drawing.Size(114, 31)
        Me.txtAY.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 77)
        Me.Label2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 25)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "y:"
        '
        'txtAX
        '
        Me.txtAX.Location = New System.Drawing.Point(146, 31)
        Me.txtAX.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtAX.Name = "txtAX"
        Me.txtAX.Size = New System.Drawing.Size(114, 31)
        Me.txtAX.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtMagB)
        Me.GroupBox2.Controls.Add(Me.txtBY)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.txtBX)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(350, 25)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox2.Size = New System.Drawing.Size(292, 177)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Vector B"
        '
        'txtMagB
        '
        Me.txtMagB.Location = New System.Drawing.Point(150, 125)
        Me.txtMagB.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtMagB.Name = "txtMagB"
        Me.txtMagB.Size = New System.Drawing.Size(114, 31)
        Me.txtMagB.TabIndex = 7
        '
        'txtBY
        '
        Me.txtBY.Location = New System.Drawing.Point(150, 77)
        Me.txtBY.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtBY.Name = "txtBY"
        Me.txtBY.Size = New System.Drawing.Size(110, 31)
        Me.txtBY.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 125)
        Me.Label6.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 25)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "magnitude:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 77)
        Me.Label3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "y:"
        '
        'txtBX
        '
        Me.txtBX.Location = New System.Drawing.Point(150, 31)
        Me.txtBX.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtBX.Name = "txtBX"
        Me.txtBX.Size = New System.Drawing.Size(110, 31)
        Me.txtBX.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 31)
        Me.Label4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 25)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "x:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(28, 213)
        Me.btnCalculate.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(1249, 44)
        Me.btnCalculate.TabIndex = 5
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtAMagNorm)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.txtAYNorm)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.txtAXNorm)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Location = New System.Drawing.Point(28, 269)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox3.Size = New System.Drawing.Size(294, 177)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Vector A Normalized"
        '
        'txtAMagNorm
        '
        Me.txtAMagNorm.Location = New System.Drawing.Point(146, 125)
        Me.txtAMagNorm.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtAMagNorm.Name = "txtAMagNorm"
        Me.txtAMagNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtAMagNorm.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 125)
        Me.Label7.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(118, 25)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "magnitude:"
        '
        'txtAYNorm
        '
        Me.txtAYNorm.Location = New System.Drawing.Point(146, 77)
        Me.txtAYNorm.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtAYNorm.Name = "txtAYNorm"
        Me.txtAYNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtAYNorm.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 77)
        Me.Label8.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 25)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "y:"
        '
        'txtAXNorm
        '
        Me.txtAXNorm.Location = New System.Drawing.Point(146, 31)
        Me.txtAXNorm.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtAXNorm.Name = "txtAXNorm"
        Me.txtAXNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtAXNorm.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 31)
        Me.Label9.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(29, 25)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "x:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtBMagNorm)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.txtBYNorm)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.txtBXNorm)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Location = New System.Drawing.Point(348, 269)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.GroupBox4.Size = New System.Drawing.Size(294, 177)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Vector B Normalized"
        '
        'txtBMagNorm
        '
        Me.txtBMagNorm.Location = New System.Drawing.Point(146, 125)
        Me.txtBMagNorm.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtBMagNorm.Name = "txtBMagNorm"
        Me.txtBMagNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtBMagNorm.TabIndex = 5
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(12, 125)
        Me.Label10.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(118, 25)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "magnitude:"
        '
        'txtBYNorm
        '
        Me.txtBYNorm.Location = New System.Drawing.Point(146, 77)
        Me.txtBYNorm.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtBYNorm.Name = "txtBYNorm"
        Me.txtBYNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtBYNorm.TabIndex = 3
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(12, 77)
        Me.Label11.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(29, 25)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "y:"
        '
        'txtBXNorm
        '
        Me.txtBXNorm.Location = New System.Drawing.Point(146, 31)
        Me.txtBXNorm.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtBXNorm.Name = "txtBXNorm"
        Me.txtBXNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtBXNorm.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(12, 31)
        Me.Label12.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(29, 25)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "x:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(26, 460)
        Me.Label13.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(56, 25)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Add:"
        '
        'txtAdd
        '
        Me.txtAdd.Location = New System.Drawing.Point(152, 454)
        Me.txtAdd.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtAdd.Name = "txtAdd"
        Me.txtAdd.Size = New System.Drawing.Size(196, 31)
        Me.txtAdd.TabIndex = 9
        '
        'txtSubtract
        '
        Me.txtSubtract.Location = New System.Drawing.Point(152, 504)
        Me.txtSubtract.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtSubtract.Name = "txtSubtract"
        Me.txtSubtract.Size = New System.Drawing.Size(196, 31)
        Me.txtSubtract.TabIndex = 11
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(26, 510)
        Me.Label14.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 25)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "Subtract:"
        '
        'txtMultiply
        '
        Me.txtMultiply.Location = New System.Drawing.Point(152, 554)
        Me.txtMultiply.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtMultiply.Name = "txtMultiply"
        Me.txtMultiply.Size = New System.Drawing.Size(196, 31)
        Me.txtMultiply.TabIndex = 13
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(26, 560)
        Me.Label15.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(121, 25)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "Multiply x2:"
        '
        'txtDistance
        '
        Me.txtDistance.Location = New System.Drawing.Point(152, 604)
        Me.txtDistance.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtDistance.Name = "txtDistance"
        Me.txtDistance.Size = New System.Drawing.Size(196, 31)
        Me.txtDistance.TabIndex = 15
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(26, 610)
        Me.Label16.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(102, 25)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "Distance:"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtMagD)
        Me.GroupBox5.Controls.Add(Me.txtDY)
        Me.GroupBox5.Controls.Add(Me.Label17)
        Me.GroupBox5.Controls.Add(Me.Label18)
        Me.GroupBox5.Controls.Add(Me.txtDX)
        Me.GroupBox5.Controls.Add(Me.Label19)
        Me.GroupBox5.Location = New System.Drawing.Point(985, 25)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(6)
        Me.GroupBox5.Size = New System.Drawing.Size(292, 177)
        Me.GroupBox5.TabIndex = 17
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Vector D"
        '
        'txtMagD
        '
        Me.txtMagD.Location = New System.Drawing.Point(150, 125)
        Me.txtMagD.Margin = New System.Windows.Forms.Padding(6)
        Me.txtMagD.Name = "txtMagD"
        Me.txtMagD.Size = New System.Drawing.Size(114, 31)
        Me.txtMagD.TabIndex = 7
        '
        'txtDY
        '
        Me.txtDY.Location = New System.Drawing.Point(150, 77)
        Me.txtDY.Margin = New System.Windows.Forms.Padding(6)
        Me.txtDY.Name = "txtDY"
        Me.txtDY.Size = New System.Drawing.Size(110, 31)
        Me.txtDY.TabIndex = 3
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(16, 125)
        Me.Label17.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(118, 25)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "magnitude:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(12, 77)
        Me.Label18.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(29, 25)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "y:"
        '
        'txtDX
        '
        Me.txtDX.Location = New System.Drawing.Point(150, 32)
        Me.txtDX.Margin = New System.Windows.Forms.Padding(6)
        Me.txtDX.Name = "txtDX"
        Me.txtDX.Size = New System.Drawing.Size(110, 31)
        Me.txtDX.TabIndex = 1
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(12, 31)
        Me.Label19.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(29, 25)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "x:"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.txtMagC)
        Me.GroupBox6.Controls.Add(Me.Label20)
        Me.GroupBox6.Controls.Add(Me.txtCY)
        Me.GroupBox6.Controls.Add(Me.Label21)
        Me.GroupBox6.Controls.Add(Me.txtCX)
        Me.GroupBox6.Controls.Add(Me.Label22)
        Me.GroupBox6.Location = New System.Drawing.Point(661, 25)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(6)
        Me.GroupBox6.Size = New System.Drawing.Size(294, 177)
        Me.GroupBox6.TabIndex = 16
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Vector C"
        '
        'txtMagC
        '
        Me.txtMagC.Location = New System.Drawing.Point(146, 125)
        Me.txtMagC.Margin = New System.Windows.Forms.Padding(6)
        Me.txtMagC.Name = "txtMagC"
        Me.txtMagC.Size = New System.Drawing.Size(114, 31)
        Me.txtMagC.TabIndex = 5
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(12, 125)
        Me.Label20.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(118, 25)
        Me.Label20.TabIndex = 4
        Me.Label20.Text = "magnitude:"
        '
        'txtCY
        '
        Me.txtCY.Location = New System.Drawing.Point(146, 77)
        Me.txtCY.Margin = New System.Windows.Forms.Padding(6)
        Me.txtCY.Name = "txtCY"
        Me.txtCY.Size = New System.Drawing.Size(114, 31)
        Me.txtCY.TabIndex = 3
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(12, 77)
        Me.Label21.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(29, 25)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "y:"
        '
        'txtCX
        '
        Me.txtCX.Location = New System.Drawing.Point(146, 32)
        Me.txtCX.Margin = New System.Windows.Forms.Padding(6)
        Me.txtCX.Name = "txtCX"
        Me.txtCX.Size = New System.Drawing.Size(114, 31)
        Me.txtCX.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(12, 31)
        Me.Label22.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(29, 25)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "x:"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.txtDMagNorm)
        Me.GroupBox7.Controls.Add(Me.Label23)
        Me.GroupBox7.Controls.Add(Me.txtDYNorm)
        Me.GroupBox7.Controls.Add(Me.Label24)
        Me.GroupBox7.Controls.Add(Me.txtDXNorm)
        Me.GroupBox7.Controls.Add(Me.Label25)
        Me.GroupBox7.Location = New System.Drawing.Point(983, 269)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(6)
        Me.GroupBox7.Size = New System.Drawing.Size(294, 177)
        Me.GroupBox7.TabIndex = 9
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Vector D Normalized"
        '
        'txtDMagNorm
        '
        Me.txtDMagNorm.Location = New System.Drawing.Point(146, 125)
        Me.txtDMagNorm.Margin = New System.Windows.Forms.Padding(6)
        Me.txtDMagNorm.Name = "txtDMagNorm"
        Me.txtDMagNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtDMagNorm.TabIndex = 5
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(12, 125)
        Me.Label23.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(118, 25)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "magnitude:"
        '
        'txtDYNorm
        '
        Me.txtDYNorm.Location = New System.Drawing.Point(146, 77)
        Me.txtDYNorm.Margin = New System.Windows.Forms.Padding(6)
        Me.txtDYNorm.Name = "txtDYNorm"
        Me.txtDYNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtDYNorm.TabIndex = 3
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(12, 77)
        Me.Label24.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(29, 25)
        Me.Label24.TabIndex = 2
        Me.Label24.Text = "y:"
        '
        'txtDXNorm
        '
        Me.txtDXNorm.Location = New System.Drawing.Point(146, 31)
        Me.txtDXNorm.Margin = New System.Windows.Forms.Padding(6)
        Me.txtDXNorm.Name = "txtDXNorm"
        Me.txtDXNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtDXNorm.TabIndex = 1
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(12, 31)
        Me.Label25.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(29, 25)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "x:"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.txtCMagNorm)
        Me.GroupBox8.Controls.Add(Me.Label26)
        Me.GroupBox8.Controls.Add(Me.txtCYNorm)
        Me.GroupBox8.Controls.Add(Me.Label27)
        Me.GroupBox8.Controls.Add(Me.txtCXNorm)
        Me.GroupBox8.Controls.Add(Me.Label28)
        Me.GroupBox8.Location = New System.Drawing.Point(663, 269)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(6)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(6)
        Me.GroupBox8.Size = New System.Drawing.Size(294, 177)
        Me.GroupBox8.TabIndex = 8
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Vector C Normalized"
        '
        'txtCMagNorm
        '
        Me.txtCMagNorm.Location = New System.Drawing.Point(146, 125)
        Me.txtCMagNorm.Margin = New System.Windows.Forms.Padding(6)
        Me.txtCMagNorm.Name = "txtCMagNorm"
        Me.txtCMagNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtCMagNorm.TabIndex = 5
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(12, 125)
        Me.Label26.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(118, 25)
        Me.Label26.TabIndex = 4
        Me.Label26.Text = "magnitude:"
        '
        'txtCYNorm
        '
        Me.txtCYNorm.Location = New System.Drawing.Point(146, 77)
        Me.txtCYNorm.Margin = New System.Windows.Forms.Padding(6)
        Me.txtCYNorm.Name = "txtCYNorm"
        Me.txtCYNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtCYNorm.TabIndex = 3
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(12, 77)
        Me.Label27.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(29, 25)
        Me.Label27.TabIndex = 2
        Me.Label27.Text = "y:"
        '
        'txtCXNorm
        '
        Me.txtCXNorm.Location = New System.Drawing.Point(146, 31)
        Me.txtCXNorm.Margin = New System.Windows.Forms.Padding(6)
        Me.txtCXNorm.Name = "txtCXNorm"
        Me.txtCXNorm.Size = New System.Drawing.Size(114, 31)
        Me.txtCXNorm.TabIndex = 1
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(12, 31)
        Me.Label28.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(29, 25)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "x:"
        '
        'txtdisCD
        '
        Me.txtdisCD.Location = New System.Drawing.Point(782, 604)
        Me.txtdisCD.Margin = New System.Windows.Forms.Padding(6)
        Me.txtdisCD.Name = "txtdisCD"
        Me.txtdisCD.Size = New System.Drawing.Size(196, 31)
        Me.txtdisCD.TabIndex = 25
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(656, 610)
        Me.Label29.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(102, 25)
        Me.Label29.TabIndex = 24
        Me.Label29.Text = "Distance:"
        '
        'txtMultiplyCD
        '
        Me.txtMultiplyCD.Location = New System.Drawing.Point(782, 554)
        Me.txtMultiplyCD.Margin = New System.Windows.Forms.Padding(6)
        Me.txtMultiplyCD.Name = "txtMultiplyCD"
        Me.txtMultiplyCD.Size = New System.Drawing.Size(196, 31)
        Me.txtMultiplyCD.TabIndex = 23
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(656, 560)
        Me.Label30.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(121, 25)
        Me.Label30.TabIndex = 22
        Me.Label30.Text = "Multiply x2:"
        '
        'txtsubCD
        '
        Me.txtsubCD.Location = New System.Drawing.Point(782, 504)
        Me.txtsubCD.Margin = New System.Windows.Forms.Padding(6)
        Me.txtsubCD.Name = "txtsubCD"
        Me.txtsubCD.Size = New System.Drawing.Size(196, 31)
        Me.txtsubCD.TabIndex = 21
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(656, 510)
        Me.Label31.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(98, 25)
        Me.Label31.TabIndex = 20
        Me.Label31.Text = "Subtract:"
        '
        'txtaddCD
        '
        Me.txtaddCD.Location = New System.Drawing.Point(782, 454)
        Me.txtaddCD.Margin = New System.Windows.Forms.Padding(6)
        Me.txtaddCD.Name = "txtaddCD"
        Me.txtaddCD.Size = New System.Drawing.Size(196, 31)
        Me.txtaddCD.TabIndex = 19
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(656, 460)
        Me.Label32.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(56, 25)
        Me.Label32.TabIndex = 18
        Me.Label32.Text = "Add:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1322, 926)
        Me.Controls.Add(Me.txtdisCD)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.txtMultiplyCD)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.txtsubCD)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.txtaddCD)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.txtDistance)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txtMultiply)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.txtSubtract)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txtAdd)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.Name = "Form1"
        Me.Text = "Vector2D Test"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtMagA As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtAY As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtAX As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtBY As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtBX As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents txtMagB As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAMagNorm As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtAYNorm As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtAXNorm As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtBMagNorm As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtBYNorm As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtBXNorm As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtAdd As System.Windows.Forms.TextBox
    Friend WithEvents txtSubtract As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtMultiply As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtDistance As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents txtMagD As TextBox
    Friend WithEvents txtDY As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtDX As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents txtMagC As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtCY As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents txtCX As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents txtDMagNorm As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents txtDYNorm As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents txtDXNorm As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents txtCMagNorm As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents txtCYNorm As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents txtCXNorm As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents txtdisCD As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents txtMultiplyCD As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents txtsubCD As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents txtaddCD As TextBox
    Friend WithEvents Label32 As Label
End Class
