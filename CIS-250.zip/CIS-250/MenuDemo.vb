﻿Module MenuDemo

    Sub Main()
        Dim a As Double
        Dim b As Double
        Dim result As Double
        Dim selection As Char
        Const QUIT As Char = "G"

        Do
            ' Display menu
            Console.Write(vbCrLf & "a = " & a)
            Console.WriteLine(vbTab & "b = " & b)
            Console.WriteLine()
            Console.WriteLine("A.  Change value of a")
            Console.WriteLine("B.  Change value of b")
            Console.WriteLine("C.  Add a + b")
            Console.WriteLine("D.  Subtract a - b")
            Console.WriteLine("E.  Multiply a * b")
            Console.WriteLine("F.  Divide a / b")
            Console.WriteLine("G.  Quit")

            ' Get user's selection
            Console.Write("Enter selection: ")
            selection = Console.ReadLine()

            ' Respond to selection
            Select Case selection
                Case "A", "a"
                    Console.Write("Enter new value: ")
                    a = Console.ReadLine()
                Case "B", "b"
                    Console.Write("Enter new value: ")
                    b = Console.ReadLine()
                Case "C", "c"
                    result = a + b
                    Console.WriteLine("{0} + {1} = {2}", a, b, result)
                Case "D", "d"
                    result = a - b
                    Console.WriteLine("{0} - {1} = {2}", a, b, result)
                Case "E", "e"
                    result = a * b
                    Console.WriteLine("{0} * {1} = {2}", a, b, result)
                Case "F", "f"
                    If (b = 0) Then
                        Console.WriteLine("ERROR:  Cannot divide by zero.")
                    Else
                        result = a / b
                        Console.WriteLine("{0} / {1} = {2}", a, b, result)
                    End If
                Case "G", "g"
                    Console.WriteLine("Exiting program...")
                Case Else
                    Console.WriteLine("ERROR:  Invalid selection.")
            End Select

        Loop While UCase(selection) <> QUIT
        ' Repeat until user says quit
    End Sub

End Module
