﻿Public Class VectorList
    Const MAX_COUNT As Integer = 100
    Private m_vectors(MAX_COUNT) As Vector2D
    Private m_count As Integer = 0

    Public Sub add(v As Vector2D)
        m_vectors(m_count) = v
        m_count += 1
    End Sub

    Public Function getVector(ByVal index As Integer) As Vector2D
        If index >= 0 And index < m_count Then
            Return m_vectors(index)
        End If

        Return Nothing
    End Function

    Public ReadOnly Property Count() As Integer
        Get
            Return m_count
        End Get
    End Property


End Class
