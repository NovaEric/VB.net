﻿Public Class Form1
    'variables

    Dim Audi(MaxLap - 1) As Double
    Dim BMW(MaxLap - 1) As Double
    Dim UserTeam As Integer = 0 'hold user option as 1 for Audi and 2 for BMW
    Const MaxLap As Integer = 10
    Dim Audiscore As Integer
    Dim BMWscore As Integer
    Dim LabWinner(MaxLap - 1) As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Text = "Team Audi Selected"
        Button2.Text = "Team BMW"
        Button1.BackColor = Color.SeaGreen
        Button2.Text.ToLower()
        Button2.BackColor = Color.Firebrick
        UserTeam = 1
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Button2.Text = "Team BMW Selected"
        Button1.Text = "Team Audi"
        Button2.BackColor = Color.SeaGreen
        Button1.Text.ToLower()
        Button1.BackColor = Color.Firebrick
        UserTeam = 2
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        'make sure user pick a team
        If UserTeam = 0 Then

            MessageBox.Show("Please Pick a Team")

        Else

            'display info

            TextBox1.AppendText("       Audi " & "      BMW")

            For index = 0 To MaxLap - 1

                Race()
                TextBox1.AppendText(vbCrLf & index + 1 & ".          " & Audi(index) & "              " & BMW(index) & "              " & LabWinner(index))

            Next

            If Audiscore > BMWscore Then

                TextBox1.AppendText(vbCrLf)
                TextBox1.AppendText(vbCrLf & "The Winner of the Race is Team AUDI!")

                If UserTeam = 1 Then
                    TextBox1.AppendText(vbCrLf & "Your Team Won Congrats!")
                ElseIf UserTeam = 2 Then
                    TextBox1.AppendText(vbCrLf & "Sorry Try Again. Your Team Lose!")
                End If

            ElseIf Audiscore < BMWscore Then

                TextBox1.AppendText(vbCrLf)
                TextBox1.AppendText(vbCrLf & "The Winner of the Race is Team BMW!")

                If UserTeam = 1 Then
                    TextBox1.AppendText(vbCrLf & "Sorry Try Again. Your Team Lose!")
                ElseIf UserTeam = 2 Then
                    TextBox1.AppendText(vbCrLf & "Your Team Won Congrats!")
                End If
            Else

                TextBox1.AppendText(vbCrLf)
                TextBox1.AppendText(vbCrLf & "Its a Draw No Winner")
                TextBox1.AppendText(vbCrLf & "Your Team Did OK!")

            End If

        End If

        Button3.Enabled = False

    End Sub

    'calculate winner audi=true bmw =false

    Sub Race()

        For index = 0 To MaxLap - 1

            Audi(index) = Carspeed()

            BMW(index) = Carspeed()

            If Audi(index) > BMW(index) Then

                Audiscore += 1
                LabWinner(index) = "Team Audi Wins"

            ElseIf Audi(index) < BMW(index) Then

                BMWscore += 1
                LabWinner(index) = "Team BMW Wins"

            ElseIf Audi(index) = BMW(index) Then

                LabWinner(index) = "Draw (No Winner)"

            End If
                       
        Next

    End Sub

    'getting speed

    Function Carspeed() As Double
        Dim speed As Random = New Random()
        Return speed.Next(Int(10 * Rnd() + 1))
    End Function

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        Button3.Enabled = True
        TextBox1.Text = ""
        Button1.Text = "Audi"
        Button2.Text = "BMW"
        Button1.BackColor = Color.Firebrick
        Button2.BackColor = Color.Firebrick
        UserTeam = 0
        Audi(MaxLap - 1) = 0
        BMW(MaxLap - 1) = 0
        BMWscore = 0
        Audiscore = 0
        LabWinner(MaxLap - 1) = ""

    End Sub
End Class
