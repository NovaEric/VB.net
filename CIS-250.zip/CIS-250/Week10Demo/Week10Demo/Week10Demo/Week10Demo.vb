﻿Public Class frmAboutMe

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub frmAboutMe_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtName.Text = ""
        radMale.Checked = False
        radFemale.Checked = False
        radOtherGender.Checked = False
        cboMajor.Text = ""
        chkMusic.Checked = False
        chkSports.Checked = False
        chkVideoGames.Checked = False
        txtResult.Text = ""
    End Sub


    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim name As String = txtName.Text
        If name = "" Then
            MessageBox.Show("Please enter your name.")
            Return
        End If

        Dim salutation As String
        If radMale.Checked Then
            salutation = "Mr. "
        ElseIf radFemale.Checked Then
            salutation = "Ms. "
        ElseIf radOtherGender.Checked Then
            salutation = ""
        Else
            MessageBox.Show("Please select your gender.")
            Return
        End If

        Dim major As String = cboMajor.Text
        If major = "" Then
            MessageBox.Show("Please select your field of study.")
        End If

        Dim hobbies As String = ""
        If Not chkMusic.Checked And _
            Not chkSports.Checked And _
            Not chkVideoGames.Checked Then
            hobbies = name & " has no known hobbies."
        Else
            hobbies = name & "'s hobbies include "
            If chkMusic.Checked Then
                hobbies = hobbies & "music, "
            End If
            If chkSports.Checked Then
                hobbies = hobbies & "sports, "
            End If
            If chkVideoGames.Checked Then
                hobbies = hobbies & "video games, "
            End If
            hobbies = hobbies & "among other things."
        End If

        Dim output As String = "About " & name
        output = output & vbCrLf & vbCrLf
        output = output & salutation & name & " is currently studying "
        output = output & major & " at Triton College." & vbCrLf & vbCrLf
        output = output & hobbies

        txtResult.Text = output

    End Sub

    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        Application.Exit()
    End Sub
End Class
