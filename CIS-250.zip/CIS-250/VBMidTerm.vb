﻿Module Module1

    'Global Variables
    Dim number, total, counter, average As Double

    Sub Main()

        Dim endloop As Boolean = False

        AskUser()
        If number = -1 Then
            endloop = True
        End If
        While endloop = False


            Display()
            AskUser()

            If number = -1 Then
                endloop = True
            End If

        End While

    End Sub

    'Prompt User for a number
    Sub AskUser()

        Try

            Console.WriteLine("Enter Number or -1 to exit: ")
            number = Console.ReadLine()
        Catch ex As Exception
            Console.WriteLine("Wrong input! hit any key to continue...")
            Console.ReadKey()
        End Try

    End Sub

    'Printer
    Sub Display()
        Console.WriteLine("Inputs Entered: " + Countracker().ToString)
        Console.WriteLine("Total Value Entered: " + TotalValue().ToString)
        Console.WriteLine("Average Value of Inputs Entered: " + AVG().ToString)
    End Sub

    'counter
    Private Function Countracker() As Double
        counter += 1
        Return counter
    End Function

    'total 
    Private Function TotalValue() As Double
        total += number
        Return total
    End Function

    'Average
    Private Function AVG() As Double
        average = total / counter
        Return average
    End Function

End Module

