﻿Public Class Form1

    Dim whoseTurn As Char = "X"
    Dim gameBoard(2, 2) As Char

    Private Sub reset()
        whoseTurn = "X"
        lblWhoseTurn.Text = "It's Player " & whoseTurn & "'s turn."
        For row As Integer = 0 To 2
            For col As Integer = 0 To 2
                gameBoard(row, col) = " "
            Next
        Next
        btn00.Text = " "
        btn00.Enabled = True
        btn01.Text = " "
        btn01.Enabled = True
        btn02.Text = " "
        btn02.Enabled = True
        btn10.Text = " "
        btn10.Enabled = True
        btn11.Text = " "
        btn11.Enabled = True
        btn12.Text = " "
        btn12.Enabled = True
        btn20.Text = " "
        btn20.Enabled = True
        btn21.Text = " "
        btn21.Enabled = True
        btn22.Text = " "
        btn22.Enabled = True

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        reset()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        reset()
    End Sub

    Private Function checkWinner() As Char
        ' Horizontal
        For r As Integer = 0 To 2
            If gameBoard(r, 0) = gameBoard(r, 1) And _
                gameBoard(r, 0) = gameBoard(r, 2) And _
                gameBoard(r, 0) <> " " Then
                Return gameBoard(r, 0)
            End If
        Next

        ' Vertical
        For c As Integer = 0 To 2
            If gameBoard(0, c) = gameBoard(1, c) And _
                gameBoard(0, c) = gameBoard(2, c) And _
                gameBoard(0, c) <> " " Then
                Return gameBoard(0, c)
            End If
        Next

        ' Diagonal
        If gameBoard(0, 0) = gameBoard(1, 1) And _
            gameBoard(0, 0) = gameBoard(2, 2) And _
            gameBoard(0, 0) <> " " Then
            Return gameBoard(0, 0)
        End If

        If gameBoard(0, 2) = gameBoard(1, 1) And _
            gameBoard(0, 2) = gameBoard(2, 0) And _
            gameBoard(0, 2) <> " " Then
            Return gameBoard(0, 2)
        End If

        Return " "
    End Function

    Private Sub playerMove(btn As Button)
        btn.Text = whoseTurn
        btn.Enabled = False
        If whoseTurn = "X" Then
            whoseTurn = "O"
        Else
            whoseTurn = "X"
        End If
        lblWhoseTurn.Text = "It's Player " & whoseTurn & "'s turn."

        Dim winner As Char = checkWinner()
        If winner <> " " Then
            MessageBox.Show("GAME OVER! Player " & winner & " wins!")
        End If
    End Sub

    Private Sub btn00_Click(sender As Object, e As EventArgs) Handles btn00.Click
        gameBoard(0, 0) = whoseTurn
        playerMove(btn00)
    End Sub

    Private Sub btn01_Click(sender As Object, e As EventArgs) Handles btn01.Click
        gameBoard(0, 1) = whoseTurn
        playerMove(btn01)
    End Sub

    Private Sub btn02_Click(sender As Object, e As EventArgs) Handles btn02.Click
        gameBoard(0, 2) = whoseTurn
        playerMove(btn02)
    End Sub

    Private Sub btn10_Click(sender As Object, e As EventArgs) Handles btn10.Click
        gameBoard(1, 0) = whoseTurn
        playerMove(btn10)
    End Sub

    Private Sub btn11_Click(sender As Object, e As EventArgs) Handles btn11.Click
        gameBoard(1, 1) = whoseTurn
        playerMove(btn11)
    End Sub

    Private Sub btn12_Click(sender As Object, e As EventArgs) Handles btn12.Click
        gameBoard(1, 2) = whoseTurn
        playerMove(btn12)
    End Sub

    Private Sub btn20_Click(sender As Object, e As EventArgs) Handles btn20.Click
        gameBoard(2, 0) = whoseTurn
        playerMove(btn20)
    End Sub

    Private Sub btn21_Click(sender As Object, e As EventArgs) Handles btn21.Click
        gameBoard(2, 1) = whoseTurn
        playerMove(btn21)
    End Sub

    Private Sub btn22_Click(sender As Object, e As EventArgs) Handles btn22.Click
        gameBoard(2, 2) = whoseTurn
        playerMove(btn22)
    End Sub
End Class
