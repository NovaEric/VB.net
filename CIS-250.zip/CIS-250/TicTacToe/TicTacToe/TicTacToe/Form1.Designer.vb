﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn00 = New System.Windows.Forms.Button()
        Me.btn01 = New System.Windows.Forms.Button()
        Me.btn02 = New System.Windows.Forms.Button()
        Me.btn10 = New System.Windows.Forms.Button()
        Me.btn11 = New System.Windows.Forms.Button()
        Me.btn12 = New System.Windows.Forms.Button()
        Me.btn20 = New System.Windows.Forms.Button()
        Me.btn21 = New System.Windows.Forms.Button()
        Me.btn22 = New System.Windows.Forms.Button()
        Me.lblWhoseTurn = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn00
        '
        Me.btn00.Location = New System.Drawing.Point(15, 34)
        Me.btn00.Name = "btn00"
        Me.btn00.Size = New System.Drawing.Size(90, 90)
        Me.btn00.TabIndex = 0
        Me.btn00.Text = "Button1"
        Me.btn00.UseVisualStyleBackColor = True
        '
        'btn01
        '
        Me.btn01.Location = New System.Drawing.Point(111, 33)
        Me.btn01.Name = "btn01"
        Me.btn01.Size = New System.Drawing.Size(90, 90)
        Me.btn01.TabIndex = 1
        Me.btn01.Text = "Button2"
        Me.btn01.UseVisualStyleBackColor = True
        '
        'btn02
        '
        Me.btn02.Location = New System.Drawing.Point(207, 33)
        Me.btn02.Name = "btn02"
        Me.btn02.Size = New System.Drawing.Size(90, 90)
        Me.btn02.TabIndex = 2
        Me.btn02.Text = "Button3"
        Me.btn02.UseVisualStyleBackColor = True
        '
        'btn10
        '
        Me.btn10.Location = New System.Drawing.Point(15, 130)
        Me.btn10.Name = "btn10"
        Me.btn10.Size = New System.Drawing.Size(90, 90)
        Me.btn10.TabIndex = 3
        Me.btn10.Text = "Button4"
        Me.btn10.UseVisualStyleBackColor = True
        '
        'btn11
        '
        Me.btn11.Location = New System.Drawing.Point(111, 129)
        Me.btn11.Name = "btn11"
        Me.btn11.Size = New System.Drawing.Size(90, 90)
        Me.btn11.TabIndex = 4
        Me.btn11.Text = "Button5"
        Me.btn11.UseVisualStyleBackColor = True
        '
        'btn12
        '
        Me.btn12.Location = New System.Drawing.Point(207, 129)
        Me.btn12.Name = "btn12"
        Me.btn12.Size = New System.Drawing.Size(90, 90)
        Me.btn12.TabIndex = 5
        Me.btn12.Text = "Button6"
        Me.btn12.UseVisualStyleBackColor = True
        '
        'btn20
        '
        Me.btn20.Location = New System.Drawing.Point(15, 227)
        Me.btn20.Name = "btn20"
        Me.btn20.Size = New System.Drawing.Size(90, 90)
        Me.btn20.TabIndex = 6
        Me.btn20.Text = "Button7"
        Me.btn20.UseVisualStyleBackColor = True
        '
        'btn21
        '
        Me.btn21.Location = New System.Drawing.Point(111, 226)
        Me.btn21.Name = "btn21"
        Me.btn21.Size = New System.Drawing.Size(90, 90)
        Me.btn21.TabIndex = 7
        Me.btn21.Text = "Button8"
        Me.btn21.UseVisualStyleBackColor = True
        '
        'btn22
        '
        Me.btn22.Location = New System.Drawing.Point(207, 225)
        Me.btn22.Name = "btn22"
        Me.btn22.Size = New System.Drawing.Size(90, 90)
        Me.btn22.TabIndex = 8
        Me.btn22.Text = "Button9"
        Me.btn22.UseVisualStyleBackColor = True
        '
        'lblWhoseTurn
        '
        Me.lblWhoseTurn.AutoSize = True
        Me.lblWhoseTurn.Location = New System.Drawing.Point(13, 13)
        Me.lblWhoseTurn.Name = "lblWhoseTurn"
        Me.lblWhoseTurn.Size = New System.Drawing.Size(96, 13)
        Me.lblWhoseTurn.TabIndex = 9
        Me.lblWhoseTurn.Text = "It is Player X's turn."
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(222, 323)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 10
        Me.btnReset.Text = "Play Again"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(309, 358)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.lblWhoseTurn)
        Me.Controls.Add(Me.btn22)
        Me.Controls.Add(Me.btn21)
        Me.Controls.Add(Me.btn20)
        Me.Controls.Add(Me.btn12)
        Me.Controls.Add(Me.btn11)
        Me.Controls.Add(Me.btn10)
        Me.Controls.Add(Me.btn02)
        Me.Controls.Add(Me.btn01)
        Me.Controls.Add(Me.btn00)
        Me.Name = "Form1"
        Me.Text = "Tic Tac Toe"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn00 As System.Windows.Forms.Button
    Friend WithEvents btn01 As System.Windows.Forms.Button
    Friend WithEvents btn02 As System.Windows.Forms.Button
    Friend WithEvents btn10 As System.Windows.Forms.Button
    Friend WithEvents btn11 As System.Windows.Forms.Button
    Friend WithEvents btn12 As System.Windows.Forms.Button
    Friend WithEvents btn20 As System.Windows.Forms.Button
    Friend WithEvents btn21 As System.Windows.Forms.Button
    Friend WithEvents btn22 As System.Windows.Forms.Button
    Friend WithEvents lblWhoseTurn As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button

End Class
