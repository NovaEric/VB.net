﻿Module Week6Assignment
    Const PRICE_SODA As Double = 1.0
    Const PRICE_CHIPS As Double = 1.99
    Const PRICE_CANDY As Double = 2.5

    Sub showMenu()
        Console.WriteLine("1.  Soda ({0:C})", PRICE_SODA)
        Console.WriteLine("2.  Candy ({0:C})", PRICE_CANDY)
        Console.WriteLine("3.  Chips ({0:C})", PRICE_CHIPS)
        Console.WriteLine("4.  Start Over")
        Console.WriteLine("5.  Check Out")
    End Sub

    Function inputSelection() As Integer
        Console.Write(vbCrLf & "Enter selection: ")
        Return Console.ReadLine
    End Function

    Function buy(price As Double, total As Double) As Double
        Return total + price
    End Function

    Function computeTax(subtotal As Double) As Double
        Return subtotal * 0.1
    End Function

    Function computeTotal(subtotal As Double, tax As Double) As Double
        Return subtotal + tax
    End Function

    Sub checkout(subtotal As Double)
        Dim tax As Double = computeTax(subtotal)
        Dim total As Double = computeTotal(subtotal, tax)
        Console.WriteLine("Subtotal:  {0:C}", subtotal)
        Console.WriteLine("Sales Tax:  {0:C}", tax)
        Console.WriteLine("Total:  {0:C}", total)
    End Sub

    Sub Main()

        Dim subtotal As Double = 0
        Dim selection As Integer

        Do
            Console.WriteLine("Order Subtotal:  {0:C}", subtotal)
            Console.WriteLine()
            showMenu()

            selection = inputSelection()

            Select Case selection
                Case 1
                    subtotal = buy(PRICE_SODA, subtotal)
                Case 2
                    subtotal = buy(PRICE_CANDY, subtotal)
                Case 3
                    subtotal = buy(PRICE_CHIPS, subtotal)
                Case 4
                    subtotal = 0
                Case 5
                    checkout(subtotal)
            End Select
        Loop While selection <> 5

        Console.WriteLine("Thanks for shopping with us!  Come back soon!")
        Console.ReadLine()
    End Sub
End Module
