﻿Public Class Contact
    Private first As String
    Private last As String
    Private phone As String
    Private email As String

    Public Function getData() As String
        Return first & "," & last & "," & phone & "," & email & vbCrLf
    End Function

    Public Property FirstName As String
        Get
            Return first
        End Get
        Set(value As String)
            first = value
        End Set
    End Property

    Public Property LastName As String
        Get
            Return last
        End Get
        Set(value As String)
            last = value
        End Set
    End Property

    Public Property PhoneNumber As String
        Get
            Return phone
        End Get
        Set(value As String)
            phone = value
        End Set
    End Property

    Public Property EmailAddress As String
        Get
            Return email
        End Get
        Set(value As String)
            email = value
        End Set
    End Property

End Class
